sudo python3 /home/pi/Crucial/combine.py
