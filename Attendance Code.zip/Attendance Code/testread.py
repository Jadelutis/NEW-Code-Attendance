from LCDlib import *
import LCD
import binascii
from py532lib.i2c import *
from py532lib.frame import *
from py532lib.constants import *
import beep
def Read(): 
	pn532 = Pn532_i2c()
	pn532.SAMconfigure()
	LCD.clearLCD()
	LCD.approachTagScreen() 
	card_data = pn532.read_mifare().get_data()
	beep.beep()
	clearLCD()
	UID = binascii.hexlify(card_data)
	Card_ID = UID[8:]
	end = Card_ID.decode('utf-8') 
	print(end)
	return(end)
