from LCDlib import *
import LCD
import testread
import tableCreate
from datetime import datetime
import mysql.connector
from mysql.connector import errorcode
from time import sleep


def checkIn():
    b_last_name = None
    b_first_name = None
    cnx = mysql.connector.connect(user='pi', password='raspberry', database='attendance')
    cursor = cnx.cursor()
    b_time = datetime.now().strftime('%H:%M')
    time = "'{}'".format(b_time)
    b_ID = testread.Read()
    ID = "'{}'".format(b_ID)
    hasChecked_In = None
    hasChecked_Out = None

    def insertCheck_In(date, ID, last_name, first_name, time):
        check_in = (
            "INSERT INTO {}(ID, LAST_NAME, FIRST_NAME, TIME_IN) VALUES({}, {}, {}, {})".format(date, ID, last_name,
                                                                                               first_name, time))
        # check_in = ("INSERT INTO `01/28/19`(ID, LAST_NAME, FIRST_NAME, TIME_IN) VALUES('1', 'Smith', 'John', '19:01')")
        cursor.execute(check_in)
        cnx.commit()
        cursor.close()
        cnx.close()

    username = ("SELECT LAST_NAME, FIRST_NAME FROM users "
                "WHERE ID = {}".format(ID))

    cursor.execute(username)

    for (LAST_NAME, FIRST_NAME) in cursor:
        b_last_name = "{}".format(LAST_NAME)
        b_first_name = "{}".format(FIRST_NAME)

    last_name = "'{}'".format(b_last_name)
    first_name = "'{}'".format(b_first_name)
    cnx.commit()
    date = tableCreate.create()

    check_in_status = ("SELECT TIME_IN, TIME_OUT FROM {} WHERE ID = {}".format(date, ID))

    cursor.execute(check_in_status)
    for x in cursor:
        hasChecked_In = x[0]
        hasChecked_Out = x[1]
    print(hasChecked_In)
    print(hasChecked_Out)
    print(last_name + ", " + first_name + ", " + ID + ", " + time)
    if b_last_name is not None and hasChecked_In is None and hasChecked_Out is None:
        insertCheck_In(date, ID, last_name, first_name, time)
        LCD.checkInScreen(b_first_name, b_time)
        sleep(2.5)
    elif b_last_name is not None and hasChecked_In is not None and hasChecked_Out is not None:
        insertCheck_In(date, ID, last_name, first_name, time)
        LCD.checkInScreen(b_first_name, b_time)
        sleep(2.5)
    elif b_last_name is not None and hasChecked_In is not None and hasChecked_Out is None:
        print("The specified User had already checked in previously and had not yet checked out")
        LCD.hasNotCheckedOut()
        sleep(2.5)
    else:
        print("the user id you enter is not in the database")
        LCD.clearLCD()
        LCD.nonExist()
        sleep(2.5)
        return
    print(date)
