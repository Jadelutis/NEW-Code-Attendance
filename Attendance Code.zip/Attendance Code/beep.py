#import time
#import RPi.GPIO as GPIO
#GPIO.setmode(GPIO.BCM)
#GPIO.setwarnings(False)
#Set up GPIO 21 as buzzer output
#GPIO.setup(18, GPIO.OUT)
#p = GPIO.PWM(18, 50)
#p.ChangeDutyCycle(80)
#p.ChangeFrequency(5000)
#p.start(75)
#time.sleep(.125)


import subprocess
def beep():
    subprocess.call("./beep.sh")
