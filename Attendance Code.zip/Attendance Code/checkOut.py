import mysql.connector
import datetime
import testread
import LCD
from time import sleep

def checkOut():
	TIME_IN = "None"
	TIME_OUT = "None"
	FIRST_NAME = "None"
	LAST_NAME = "None"
	cnx = mysql.connector.connect(user='pi', password='raspberry', database='attendance')
	cursor = cnx.cursor()
	date = '`' + datetime.datetime.now().strftime('%D') + '`'

	b_ID = testread.Read()
	ID = "'" + b_ID + "'"

	userExist = ("SELECT FIRST_NAME, LAST_NAME FROM users WHERE ID = {}".format(ID))
	cursor.execute(userExist)

	for NAME in cursor:
		FIRST_NAME = NAME[0]
		LAST_NAME = NAME[1]
	print(FIRST_NAME)
	print(LAST_NAME)
	if FIRST_NAME != "None":
		checkInTime = ("SELECT TIME_IN, TIME_OUT FROM {} WHERE ID = {}".format(date, ID))
		try:
			cursor.execute(checkInTime)
		except mysql.connector.Error as err:
			print(err)
			LCD.hasNotCheckedIn()
			sleep(2.5)
			return
		for (TIME_IN, TIME_OUT) in cursor:
			TIME_IN = "{}".format(TIME_IN)
			TIME_OUT = "{}".format(TIME_OUT)
		print(TIME_IN)
		OUT_TIME = datetime.datetime.now().strftime('%H:%M')
		FMT = '%H:%M'
		a_OUT_TIME = repr(OUT_TIME)
		print (a_OUT_TIME)

		#Makes sure the returned TIME_IN is valid
		if TIME_IN != "None":
			duration = datetime.datetime.strptime(OUT_TIME, FMT) - datetime.datetime.strptime(TIME_IN, FMT)

			hours = duration.seconds // 3600
			minutes = (duration.seconds % 3600) // 60

			Length = "{:02}:{:02}".format(hours, minutes)
			a_Length = repr(Length)

			checkOut = ("UPDATE {} SET TIME_OUT = {}, DURATION = {} WHERE ID = {} AND TIME_OUT IS NULL".format(date, a_OUT_TIME, a_Length, ID))

			if TIME_IN != "None" and TIME_OUT == "None":
				cursor.execute(checkOut)
				LCD.checkOutScreen(OUT_TIME)
				sleep(2.5)
				cnx.commit()
				cursor.close()
				cnx.close()
			else:
				print("Please Check In First")
				LCD.hasNotCheckedIn()
				sleep(2.5)
				return
		else:
			print("Please Check In First")
			LCD.hasNotCheckedIn()
			sleep(2.5)
			return
	else:
		LCD.nonExist()
		sleep(2.5)
		return

