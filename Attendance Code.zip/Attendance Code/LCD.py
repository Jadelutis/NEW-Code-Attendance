from LCDlib import *
from time import sleep
from datetime import datetime


def idleScreen():
	import RPi.GPIO as GPIO
	GPIO.setmode(GPIO.BCM)
	GPIO.setup(20, GPIO.IN, pull_up_down=GPIO.PUD_UP)
	GPIO.setup(21, GPIO.IN, pull_up_down=GPIO.PUD_UP)
	IN = GPIO.input(20)
	OUT = GPIO.input(21)
	clearLCD()
	printLCD("IN", 1, 0)
	printLCD("OUT", 2, 0)
	#hasExported = False
	while True:
		cTime = datetime.now().strftime('%H:%M')
		printLCD(cTime, 1, 11)
		IN = GPIO.input(20)
		OUT = GPIO.input(21)
		if IN == False:
			return("checkIn")
		elif OUT == False:
			return("checkOut")
		elif cTime != "00:01":
			hasExported = False
		# elif cTime == "00:01" and hasExported is False:
		# 	hasExported = True
		# 	return("export")
		else:
			return("error")
def loadScreen():
	clearLCD()
	num = range(0, 15)
	printLCD('Loading', 1, 4)
	for x in num:
		printLCD('*', 2, x)
		sleep(0.25)
	clearLCD()
	printLCD('88', 2, 7)
	sleep(1)
	printLCD('TJ2', 1, 6)
	printLCD('Attendance', 2, 3)
	sleep(1)
def checkInScreen(name, time):
	printLCD('Welcome{}'.format(name), 1, 0)
	printLCD('CheckIn {}'.format(time), 2, 0)

def checkOutScreen(time):
	printLCD('Good Bye', 1, 0)
	printLCD('CheckOut {}'.format(time), 2, 0)
def approachTagScreen():
	printLCD('Approach', 1, 4)
	printLCD("Tag", 2, 6)
def exporting():
	printLCD('Exporting', 1, 3)
	printLCD('Please Wait', 2, 2)
def nonExist():
	printLCD('Tag', 1, 6)
	printLCD('Not Enrolled', 2, 2)
def hasNotCheckedIn():
	printLCD('Please Check In', 1, 1)
	printLCD('First', 2, 6)
def hasNotCheckedOut():
	printLCD('Please Check Out', 1, 0)
	printLCD('First', 2, 6)

