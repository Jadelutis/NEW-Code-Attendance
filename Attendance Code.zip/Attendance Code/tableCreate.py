from datetime import datetime
import mysql.connector
from mysql.connector import errorcode
def create():
	subdate = datetime.now().strftime('%D')
	date = ("`" + subdate + "`")
	cnx = mysql.connector.connect(user='pi', password='raspberry', database='attendance')
	cursor = cnx.cursor()
	ID = "None"
	
	createTable = ("CREATE TABLE IF NOT EXISTS {} (ID VARCHAR(35) NOT NULL, LAST_NAME VARCHAR(20) NOT NULL, FIRST_NAME VARCHAR(14) NOT NULL, TIME_IN VARCHAR(5) NOT NULL, TIME_OUT VARCHAR(5), DURATION VARCHAR(5))".format(date))
	cursor.execute(createTable)
	query = ("SELECT ID FROM {} WHERE ID = 1".format(date))
	try:
		cursor.execute(query)
		for x in cursor:
			ID = x[0]
		print("ID = " + ID)
	except:
		print("errored(ignore)")
	cnx.commit()
	cursor.close()
	cnx.close()
	return date
