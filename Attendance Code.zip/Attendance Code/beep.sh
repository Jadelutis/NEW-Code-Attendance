#!/bin/bash
sudo pigs pfs 18 3700 p 18 50 mils 250 p 18 0
