import I2CLCD
from datetime import datetime

LCD = I2CLCD.lcd()

def printLCD(text, row=1, column=0):
	LCD.lcd_display_string(text, row, column)
def clearLCD():
	LCD.lcd_clear()
def LCDtime():
	LCD.lcd_display_string("{}".format(datetime.now()))
