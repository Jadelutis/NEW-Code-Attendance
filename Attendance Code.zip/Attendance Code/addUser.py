import mysql.connector
import testread

b_ID = testread.Read()
ID = "'" + b_ID + "'"
b_LAST_NAME = input("LAST_NAME?")
LAST_NAME = "'" + b_LAST_NAME + "'"
b_FIRST_NAME = input("FIRST_NAME?")
FIRST_NAME = "'" + b_FIRST_NAME + "'"

cnx = mysql.connector.connect(user='pi', password='raspberry', database='attendance')
cursor = cnx.cursor()

insert = ("INSERT INTO users (ID, LAST_NAME, FIRST_NAME) VALUES ({}, {}, {})".format(ID, LAST_NAME, FIRST_NAME))

cursor.execute(insert)
cnx.commit()
cursor.close()
cnx.close()
