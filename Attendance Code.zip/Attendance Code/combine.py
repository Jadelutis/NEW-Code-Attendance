import LCD
import checkOut
import checkIn
import mysql.connector
import subprocess
from time import sleep

subprocess.call("pigpiod")
#LCD.loadScreen()
while True:
    checkInOut = LCD.idleScreen()
    if checkInOut == ("checkIn"):
        checkIn.checkIn()
    elif checkInOut == ("checkOut"):
        checkOut.checkOut()
    # elif checkInOut == ("export"):
    #     print("export")
    #     # run export
    else:
        LCD.clearLCD()
        LCD.printLCD("ERROR!", 1, 0)
        LCD.printLCD("Please Reboot", 2, 0)
