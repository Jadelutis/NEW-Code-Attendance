import datetime
import mysql.connector
cnx = mysql.connector.connect(user='pi', password='raspberry', database='attendance')
cursor = cnx.cursor()
lname = input("lastname")
fname = input("firstname")
lastname = ("'" + lname + "'")
firstname = ("'" + fname + "'")
date = ("`" + datetime.datetime.now().strftime('%D') + "`")
print(date)

query = "SELECT DURATION FROM {} WHERE LAST_NAME = {} AND FIRST_NAME = {}".format(date, lastname, firstname)
cursor.execute(query)
FMT = '%H:%M'
z = 1
y = datetime.timedelta(0, 0)
for x in cursor:
    x = datetime.datetime.strptime(x[0], FMT) - datetime.datetime.strptime('00:00', FMT)
    y = y + x
totalHours = y.seconds // 3600
totalMinutes = (y.seconds % 3600) // 60
print(fname + " " + lname +
      " was clocked in for " +
      str(totalHours) + " hours and " +
      str(totalMinutes) +
      " minutes today.")



